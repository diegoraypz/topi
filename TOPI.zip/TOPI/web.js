var express = require('express');
var app = express();
var PORT = 3000;
function Ingresar_Usuario(usua, clave) {
    var MongoClient = require('mongodb').MongoClient;
    var uri = "mongodb+srv://jsg045:Pudge123*@cluster0-0zvai.mongodb.net/test?retryWrites=true";
    var client = new MongoClient(uri, { useNewUrlParser: true });
    client.connect(function (err) {
        var collection = client.db("Catalogo").collection("Productos");
        var p1 = { USUARIO: usua, PASSWORD: clave };
        collection.insertOne(p1, function (err, res) {
            console.log("ingrsado");
        });
        client.close();
    });
}
function main() {
    app.use(express.static(__dirname + '/views/'));
    app.listen(PORT, function () {
        console.log("Server running in port " + PORT);
    });
}
main();
