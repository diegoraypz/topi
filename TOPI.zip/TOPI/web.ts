const express = require('express')
const app = express()
const PORT = 3000

function Ingresar_Usuario(usua:string,clave:String) 
{
  const MongoClient = require('mongodb').MongoClient;
  const uri = "mongodb+srv://jsg045:Pudge123*@cluster0-0zvai.mongodb.net/test?retryWrites=true";
  const client = new MongoClient(uri, { useNewUrlParser: true });
  client.connect(err => {
  const collection = client.db("Catalogo").collection("Productos");
  var p1={USUARIO:usua,PASSWORD:clave};
  collection.insertOne(p1,function(err,res){
      console.log("ingrsado");
  });
  client.close();
});
  
}


function main()
{
  app.use(express.static(__dirname + '/views/'));

  app.listen(PORT, ()=>{
    console.log(`Server running in port ${PORT}`);
  })
}
main()








